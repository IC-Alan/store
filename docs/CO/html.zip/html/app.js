const API_HOST = "http://localhost:8080";

// 获取评论并渲染
function fetchComments() {
  fetch(`${API_HOST}/comment/get?size=-1`)
    .then(res => res.json())
    .then(resp => {
      if (resp.code === 0 && resp.data && Array.isArray(resp.data.comments)) {
        renderComments(resp.data.comments);
      }
    });
}

// 渲染评论
function renderComments(comments) {
  const commentBox = document.getElementById("commentBox");
  commentBox.innerHTML = "";
  if (comments.length === 0) {
    commentBox.style.display = "none";
    return;
  }
  commentBox.style.display = "block";
  comments.forEach(comment => {
    const commentDiv = document.createElement("div");
    commentDiv.className = "comment";
    commentDiv.setAttribute("data-id", comment.id);

    const userEl = document.createElement("div");
    userEl.className = "comment-user";
    userEl.innerText = comment.name;

    const commentEl = document.createElement("p");
    commentEl.className = "comment-text";
    commentEl.innerText = comment.content;

    const delBtn = document.createElement("button");
    delBtn.className = "comment-del-btn";
    delBtn.innerText = "删除";
    delBtn.onclick = function() {
      deleteComment(comment.id);
    };

    commentDiv.appendChild(userEl);
    commentDiv.appendChild(commentEl);
    commentDiv.appendChild(delBtn);

    commentBox.appendChild(commentDiv);
  });
}

// 添加评论
function addcomment() {
  const form = document.getElementById("commentForm");
  if (!form) return;
  const usernameInput = form.querySelector('input[name="username"]');
  const commentInput = form.querySelector('input[name="comment"]');
  if (!usernameInput || !commentInput) return;
  const username = usernameInput.value.trim();
  const comment = commentInput.value.trim();
  if (!username || !comment) {
    alert("请填写完整信息！");
    return;
  }
  fetch(`${API_HOST}/comment/add`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ name: username, content: comment })
  })
    .then(res => res.json())
    .then(resp => {
      if (resp.code === 0) {
        form.reset();
        fetchComments(); // 先清空再刷新，确保显示
      } else {
        alert(resp.msg || "添加失败");
      }
    })
    .catch(() => {
      alert("网络错误，添加失败");
    });
}

// 删除评论
function deleteComment(id) {
  fetch(`${API_HOST}/comment/delete?id=${id}`, {
    method: "POST"
  })
    .then(res => res.json())
    .then(resp => {
      if (resp.code === 0) {
        fetchComments();
      } else {
        alert(resp.msg || "删除失败");
      }
    });
}

// 初始化加载评论
fetchComments();

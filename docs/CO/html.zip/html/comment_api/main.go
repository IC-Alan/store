package main

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type Comment struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Name      string    `json:"name"`
	Content   string    `json:"content"`
	CreatedAt time.Time `json:"-"`
}

type Response struct {
	Code int         `json:"code"`
	Msg  string      `json:"msg"`
	Data interface{} `json:"data"`
}

var db *gorm.DB

func main() {
	dsn := "comment_user:@tcp(127.0.0.1:3306)/comment_db?charset=utf8mb4&parseTime=True&loc=Local"
	var err error
	db, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic("连接数据库失败: " + err.Error())
	}
	db.AutoMigrate(&Comment{})

	r := gin.Default()
	r.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE, UPDATE")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Origin, Content-Type, Accept, Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	r.GET("/comment/get", getComments)
	r.POST("/comment/add", addComment)
	r.POST("/comment/delete", deleteComment)

	r.Run(":8080")
}

func getComments(c *gin.Context) {
	pageStr := c.DefaultQuery("page", "1")
	sizeStr := c.DefaultQuery("size", "10")

	page, _ := strconv.Atoi(pageStr)
	size, _ := strconv.Atoi(sizeStr)

	var total int64
	db.Model(&Comment{}).Count(&total)

	var comments []Comment
	if size == -1 {
		db.Order("created_at desc").Find(&comments)
	} else {
		offset := (page - 1) * size
		db.Order("created_at desc").Limit(size).Offset(offset).Find(&comments)
	}

	c.JSON(http.StatusOK, Response{
		Code: 0,
		Msg:  "success",
		Data: gin.H{
			"total":    total,
			"comments": comments,
		},
	})
}

func addComment(c *gin.Context) {
	var input struct {
		Name    string `json:"name"`
		Content string `json:"content"`
	}
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, Response{Code: 1, Msg: "参数错误", Data: nil})
		return
	}

	comment := Comment{Name: input.Name, Content: input.Content}
	db.Create(&comment)

	c.JSON(http.StatusOK, Response{
		Code: 0,
		Msg:  "success",
		Data: gin.H{
			"id":      comment.ID,
			"name":    comment.Name,
			"content": comment.Content,
		},
	})
}

func deleteComment(c *gin.Context) {
	idStr := c.Query("id")
	id, err := strconv.Atoi(idStr)
	if err != nil || id <= 0 {
		c.JSON(http.StatusBadRequest, Response{Code: 1, Msg: "无效的ID", Data: nil})
		return
	}

	db.Delete(&Comment{}, id)

	c.JSON(http.StatusOK, Response{
		Code: 0,
		Msg:  "success",
		Data: nil,
	})
}
